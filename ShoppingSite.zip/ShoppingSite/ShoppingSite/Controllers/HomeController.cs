﻿using Microsoft.AspNetCore.Mvc;
using ShoppingSite.Data;
using ShoppingSite.Models;
using System.IO;
using System.Threading.Tasks;

namespace ShoppingSite.Controllers
{
    public class ProductController : Controller
    {
        private readonly ProductRepository _productRepository;

        public ProductController(ProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public async Task<IActionResult> Index()
        {
            var products = await _productRepository.GetAllProductsAsync();
            var viewModel = new EcommerceViewModel { Products = products };
            return View(viewModel);
        }


        public async Task<IActionResult> Details(int id)
        {
            var product = await _productRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreateProductViewModel productViewModel)
        {
            if (ModelState.IsValid)
            {
                // Process the uploaded image file
                if (productViewModel.ImageFile != null && productViewModel.ImageFile.Length > 0)
                {
                    // Convert the uploaded file to a byte array
                    using (var memoryStream = new MemoryStream())
                    {
                        await productViewModel.ImageFile.CopyToAsync(memoryStream);
                        var product = new Product
                        {
                            Name = productViewModel.Name,
                            Description = productViewModel.Description,
                            Price = productViewModel.Price,
                            Image = memoryStream.ToArray()
                        };
                        await _productRepository.AddProductAsync(product);
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            return View(productViewModel);
        }


        public async Task<IActionResult> Edit(int id)
        {
            var product = await _productRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Product product)
        {
            if (id != product.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                await _productRepository.UpdateProductAsync(product);
                return RedirectToAction(nameof(Index));
            }
            return View(product);
        }
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _productRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return View(product);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var product = await _productRepository.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            await _productRepository.DeleteProductAsync(product);
            return RedirectToAction(nameof(Index));
        }

    }
}