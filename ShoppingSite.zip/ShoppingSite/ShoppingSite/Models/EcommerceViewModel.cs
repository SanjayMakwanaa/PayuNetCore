﻿using System.Collections.Generic;

namespace ShoppingSite.Models
{
    public class EcommerceViewModel
    {
        public List<Product> Products { get; set; }

    }
}
