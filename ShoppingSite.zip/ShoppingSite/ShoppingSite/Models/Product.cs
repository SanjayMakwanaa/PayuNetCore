﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations.Schema;

namespace ShoppingSite.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }

        [NotMapped] // Exclude this property from database mapping
        public IFormFile ImageFile { get; set; }

        public byte[] Image { get; set; } // New property to store image data
    }
}
