﻿using Microsoft.AspNetCore.Http;

namespace ShoppingSite.Models
{
    public class CreateProductViewModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public IFormFile ImageFile { get; set; }
        public byte[] Image { get; set; } 
    }
}
