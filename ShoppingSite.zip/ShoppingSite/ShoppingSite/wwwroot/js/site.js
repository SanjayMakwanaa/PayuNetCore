﻿$(document).ready(function () {
    $('#createProductButton').click(function () {
        $('#createProductModal').modal('show');
    });
});
